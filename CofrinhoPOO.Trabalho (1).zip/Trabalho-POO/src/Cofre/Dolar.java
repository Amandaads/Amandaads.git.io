package Cofre;

import java.util.Objects;

public class Dolar extends Moeda {
	
	
	public Dolar(double valor) {
		super();
		this.setValor(valor);
	}

	public double taxa = 5.42;
	
	@Override
	public void info () {
		System.out.println("Dolar ---> U$" + getValor());
	}
	
	@Override
	double converter() {
		return getValor() * taxa;
	}
	@Override
	public int hashCode() {
		return Objects.hash(getValor());
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		return Double.doubleToLongBits(getValor()) == Double.doubleToLongBits(other.getValor());
	} 

}
