package Cofre;

import java.util.Objects;

public class Euro extends Moeda{
	public double taxa = 5.86;
	
	public Euro(double valor) {
		super();
		this.setValor(valor);
	}

	@Override
	void info() {
		System.out.println("Euro ---> € "+ getValor());
	}

	@Override
	double converter() {
		return getValor() * taxa;
	}
	@Override
	public int hashCode() {
		return Objects.hash(getValor());
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		return Double.doubleToLongBits(getValor()) == Double.doubleToLongBits(other.getValor());
	} 
	
}
