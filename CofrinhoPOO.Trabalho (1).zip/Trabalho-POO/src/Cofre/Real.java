package Cofre;

import java.util.Objects;

public class Real extends Moeda{
	
	
	public Real(double valor) {
		super();
		this.setValor(valor);
	}
	
	
	
	
	
	
	@Override
	void info() {
		System.out.println("Real ---> $" +  getValor());
		
	}
	@Override
	double converter() {
		return getValor();
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(getValor());
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		return Double.doubleToLongBits(getValor()) == Double.doubleToLongBits(other.getValor());
	} 
}

