package Cofre;

import java.util.ArrayList;
import java.util.List;

public class Cofrinho {
	private List<Moeda> moedas = new ArrayList<Moeda>();
	public double valor;

	public Cofrinho() {
		moedas.add(new Real(0));
		moedas.add(new Euro(0));
		moedas.add(new Dolar(0));
	}

	public void adicionar(Moeda moeda) {
		for (Moeda m : moedas) {
			if (m.getClass() == moeda.getClass()) {
				m.setValor(m.getValor() + moeda.getValor());
			}
		}

	}
	public void remover(Moeda moeda) {
		for (Moeda m : moedas) {
			if (m.getClass() == moeda.getClass()) {
				m.setValor(m.getValor() - moeda.getValor());
			}
		}
	}

	public void listagemMoedas() {
		if (moedas.isEmpty()) {
			System.out.println("Cofrinho vazio.");
		} else {
			System.out.println("Listagem de moedas:");
			for (Moeda moeda : moedas) {
				System.out.println(moeda.getClass().getSimpleName() + " ---> " + moeda.getValor());
			}
		}
	}

	public double valorConvertido() {
		double total = 0;
		for (Moeda m : moedas) {
			total += m.converter();
		}
		System.out.printf("Total em Reais R$ %.2f" , total);
		return total;
	}

}