package Cofre;

import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		System.out.println("Cofrinho de Amanda Dias- RU 4848296");
		Cofrinho cofrinho = new Cofrinho();

		Moeda moeda;
		Scanner sc = new Scanner(System.in);
				
		int n = -1;

		while (n != 0) {
			//menu opcões do que se pode fazer no cofrinho
			System.out.println();
			System.out.println("ESCOLHA UMA OPÇÃO");
			System.out.println("1-Adicionar moedas");
			System.out.println("2-Remover moeda");
			System.out.println("3-Listagem de moedas");
			System.out.println("4-Total convertido em reais");
			System.out.println("0-Encerrar programa");
			System.out.println();
			System.out.print("Digite sua opção: ");n = sc.nextInt(); // qual das opcoes escolhida
			
			
			if (n == 1) {
				int i = -1;
				//escolhida a opção de adicionar, menu de qual moeda adicionar
				System.out.println("Qual moeda deseja adicionar?");
				System.out.println("1 - REAL");
				System.out.println("2 - EURO");
				System.out.println("3 - DOLAR");
				System.out.print("DIGITE: ");
				i = sc.nextInt();
				if (i == 1) {
					System.out.print("Adicionar valor moeda Real: ");
					double valorReal = sc.nextDouble();
					Real real = new Real(valorReal);
					cofrinho.adicionar(real);
					}
				else if(i == 2) {
					System.out.print("Adicionar valor moeda Euro: ");
					double valorEuro = sc.nextDouble();
					Euro euro = new Euro(valorEuro);
					cofrinho.adicionar(euro);
					
				}
				else if(i == 3) {
					System.out.print("Adicionar valor moeda Dolar: ");
					double valorDolar = sc.nextDouble();
					Dolar dolar = new Dolar(valorDolar);
					cofrinho.adicionar(dolar);
				}
				}

				
			else if(n == 2) {
				int tipo;
				double valor;
				System.out.println("Opcão-Remover Moedas");
				System.out.println("Qual moeda deseja remover? ");
				System.out.println("1 - REAL");
				System.out.println("2 - EURO");
				System.out.println("3 - DOLAR");
				System.out.print("DIGITE: ");
				tipo = sc.nextInt(); // escolhendo qual o tipo da moeda que ira remover
				 // opcao de qual sera o valor
				moeda = null;
				if (tipo == 1) {
					System.out.print("Digite o valor a ser removido de Real: ");
					valor = sc.nextDouble();
					moeda = new Real(valor); 
					cofrinho.remover(moeda);
				}
				else if(tipo == 2) {
					System.out.print("Digite o valor a ser removido de Euro: ");
					valor = sc.nextDouble();
					moeda = new Euro(valor); 
					cofrinho.remover(moeda);
				}else if(tipo == 3) {
					System.out.print("Digite o valor a ser removido de Dolar: ");
					valor = sc.nextDouble();
					moeda = new Dolar(valor); 
					cofrinho.remover(moeda);
				}
				else {
					System.out.println("Tipo a ser digitado deve ser de 1 à 3!");
				}
				
			}
			// se a opcao for tres, aparecera a LISTAGEM DE MOEDAS
			else if (n == 3 ) {
				System.out.println("Listagem de moedas");
				cofrinho.listagemMoedas();
				
			}
			// se a opcao for quatro, aparecera TOTAL CONVERTIDO EM REAIS.
			else if (n == 4 ) {
				
				cofrinho.valorConvertido();		
			}
			else if (n == 0) {
				System.out.println("Programa encerrado.");
			}else {
				System.out.println("Opção indisponivel, tente novamente!");
			}
		}
    }
	}